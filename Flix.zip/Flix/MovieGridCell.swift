//
//  MovieGridCell.swift
//  Flix
//
//  Created by Asam Zaman on 10/3/21.
//

import UIKit
import AlamofireImage
class MovieGridCell: UICollectionViewCell {
    
    @IBOutlet weak var posterView: UIView!
}
